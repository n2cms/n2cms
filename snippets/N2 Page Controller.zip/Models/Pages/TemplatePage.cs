using N2;
using N2.Web;
using N2.Details;

namespace $rootnamespace$
{
	/// <summary>
	/// This class represents the data transfer object that encapsulates 
	/// the information used by the template.
	/// </summary>
	[PageDefinition("$itemname$")]
	[WithEditableTitle, WithEditableName]
	public class $safeitemname$ : ContentItem
	{
        [EditableFreeTextArea("Text", 100)]
        public virtual string Text
        {
            get { return (string)(GetDetail("Text") ?? string.Empty); }
            set { SetDetail("Text", value, string.Empty); }
        }
	}
}
