using N2;

namespace $rootnamespace$
{
	[Definition("$itemname$")]
	public class $safeitemname$ : ContentItem
	{
		public override string TemplateUrl
		{
			get { return "~/UI/$fileinputname$.ascx"; }
		}
		public override bool IsPage
		{
			get { return false; }
		}
	}
}
