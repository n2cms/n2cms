using N2;

namespace $rootnamespace$
{
	[PartDefinition("$itemname$", TemplateUrl = "~/UI/$fileinputname$.ascx")]
	public class $safeitemname$ : ContentItem
	{
	}
}
