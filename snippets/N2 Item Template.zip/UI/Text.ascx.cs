using System;
using System.Data;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using N2;

namespace $rootnamespace$
{
	public partial class $safeitemname$ : N2.Web.UI.UserControl<ContentItem, Items.$safeitemname$Item>
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}