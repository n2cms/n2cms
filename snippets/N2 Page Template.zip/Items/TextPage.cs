using N2;

namespace $rootnamespace$
{
	[Item("$itemname$")]
	public class $safeitemname$ : ContentItem
	{
		public override string TemplateUrl
		{
			get { return "~/UI/$fileinputname$.aspx"; }
		}
	}
}
